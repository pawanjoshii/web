import 'package:flutter/material.dart';

const kpink = Color(0xFFff6374);
const kblue = Color(0xFF71b8ff);
const kpurple = Color(0xFF9ba0fc);
const korange = Color(0xFFffaa5b);
